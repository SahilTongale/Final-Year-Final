from django.shortcuts import render,HttpResponseRedirect,HttpResponse,get_object_or_404
from django.http import HttpResponseForbidden
from .models import contact as c
import joblib
# email
from django.conf import settings
from django.core.mail import send_mail
# Logger Balancer
import requests
# Create your views here.

def index(request):
    # Define the URL and the headers
    url = 'http://127.0.0.1:9000/'
    headers = {'source': 'index'}
    response = requests.get(url, headers=headers)
    if response.status_code == 403:  # 403 is the status code for HttpResponseForbidden
        print("Request forbidden! IP blocked.")
        return HttpResponseForbidden("Your IP address has been blocked due to high request count.")
    else:
        print("Request successful!")
        print("Response:", response.text)
    return render(request,'index.html')

def about(request):
    return render(request,'about.html')

def prediction_page(request):
    model = joblib.load('loan_status_prediction')
    email = request.user.email
    if request.method == "POST":
        gender = int(request.POST.get('gender'))
        married = int(request.POST.get('married'))
        dependents = int(request.POST.get('dependents'))
        education = int(request.POST.get('education'))
        self_employed = int(request.POST.get('self_employed'))
        applicant_income = int(request.POST.get('applicant_income'))//1000
        coapplicant_income = int(request.POST.get('coapplicant_income'))//1000
        loan_amount = int(request.POST.get('loan_amount'))//10000
        loan_amount_term = int(request.POST.get('loan_amount_term'))*30
        credit_history = int(request.POST.get('credit_history'))
        property_area = int(request.POST.get('property_area'))

        li = [gender,married,dependents,education,self_employed,applicant_income,coapplicant_income,loan_amount,loan_amount_term,credit_history,property_area]
        prediction = model.predict([li])
        if loan_amount<=applicant_income:
            prediction = [1]
        if prediction[0] == 0:
            passing = "be approved"
        else:
            passing = "not approved"
        subject = 'Registration Message'
        message = f'''
          Your Last prediction with the values {li}.
          Looks like the Loan will {passing} as per our banking data.
        '''
        email_from = settings.EMAIL_HOST_USER
        recipient_list = [email]
        #send_mail(subject, message, email_from, recipient_list)
        print("Input List : ",li)

        return render(request,'result_page.html',context={'prediction':prediction[0]})
    return render(request,'prediction_page.html')


def contact(request):
    if request.method == "POST":
        name = request.POST.get("name")
        subject = request.POST.get("subject")
        message = request.POST.get("message")
        email = request.POST.get("email")

        save = c(name=name,subject=subject,message=message,email=email)
        save.save()
        return HttpResponseRedirect('/contact/')
    return render(request,'predict_contact.html')

def result(request):
    return render(request,'result_page.html')
