from django.urls import path
from . import views

app_name = 'predict'

urlpatterns = [
    path('',views.index,name='home'),
    path('about/',views.about,name='about'),
    path('predict/',views.prediction_page,name='predict'),
    path('contact/',views.contact,name='contact'),
    path('result/',views.result,name='result'),
]