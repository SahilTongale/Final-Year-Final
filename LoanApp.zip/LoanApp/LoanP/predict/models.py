from django.db import models

# Create your models here.
class contact(models.Model):
    name = models.CharField(max_length=256,null=True)
    email = models.CharField(max_length=256,null=True)
    subject = models.CharField(max_length=500,null=True)
    message = models.TextField()